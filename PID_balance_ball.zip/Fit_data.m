clear
clc

GP2Y0A51SK0F_data
plot(X,Y,".")