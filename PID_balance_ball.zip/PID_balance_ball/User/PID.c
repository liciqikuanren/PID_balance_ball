#include "PID.H"
#include "user_adc.h"
#include "adc.h"
#include <math.h>
#define PID_time 0.001
#define Run_Max 900
#define Run_Min -900
#define I_Max 200
#define I_Min -200
PID_struct M_PID;
void PID_Init()
{
	M_PID.Target_Data=120;
  M_PID.count=PID_time;
	M_PID.Last_Deviation=0;
  M_PID.Real_Data=0;
  M_PID.Run_Data=0;
  M_PID.P_modulus=2;
  M_PID.P_Data=0;
  M_PID.I_modulus=1;
  M_PID.I_Data=0;
	M_PID.D_modulus=0.2;
	M_PID.D_Data=0;
}
//void PID_Timing()
//{
//	if(M_PID.count>0)
//	{
//		M_PID.count--;
//	}
//}


float PID_Run(float Real_Data)
{
	float Deviation=0;//��ǰ���
//	if(M_PID.count==0)
//	{
		M_PID.Real_Data=Real_Data;
		Deviation=(M_PID.Target_Data-M_PID.Real_Data);
		if(fabs(Deviation)< 3 )
		{
			return M_PID.Run_Data;
		}
		M_PID.P_Data=Deviation*M_PID.P_modulus;
		
		M_PID.I_Data=M_PID.I_Data+Deviation*(M_PID.I_modulus*PID_time );
		if(M_PID.I_Data>I_Max)
		{
			M_PID.I_Data=I_Max;
		}
		else if(M_PID.I_Data<I_Min)
		{
			M_PID.I_Data=I_Min;
		}
		
		
		M_PID.D_Data=(Deviation-(M_PID.Last_Deviation))*(M_PID.D_modulus/PID_time);
		
		M_PID.Run_Data=M_PID.P_Data+M_PID.I_Data+M_PID.D_Data;
		
		M_PID.Last_Deviation=Deviation;
		if(M_PID.Run_Data>Run_Max)
		{
			M_PID.Run_Data=Run_Max;
		}
		else if(M_PID.Run_Data<Run_Min)
		{
			M_PID.Run_Data=Run_Min;
		}
//		M_PID.count=PID_time;
//	}
	return M_PID.Run_Data;
}
