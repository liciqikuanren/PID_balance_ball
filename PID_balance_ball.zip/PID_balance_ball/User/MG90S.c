 #include "MG90S.h"
 
 void MG90S_Run(long angle)//-900��900��λΪ��0.1��
 {
	 uint16_t Duty=0;
	 Duty =1365-angle;
	 __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_2,Duty);
 }