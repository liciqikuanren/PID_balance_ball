#include "user_adc.h"
#include "adc.h"
#include <math.h>
user_ADC_FilterTypeDef user_ADC1;
uint16_t value_buf[QUEUE_NUM];
uint16_t user_ADC1_GetValue(ADC_HandleTypeDef* hadc)
{
		 HAL_ADC_Start(hadc);     //ADC开始
	  	
		 HAL_ADC_PollForConversion(hadc, 1);   //等待ADC转换完成
 
		 if(HAL_IS_BIT_SET(HAL_ADC_GetState(hadc), HAL_ADC_STATE_REG_EOC))//判断ADC状态
		 {
				return HAL_ADC_GetValue(hadc);   //读值
		 }	
		 return 0;
}
float Fit_GP2Y0A51SK0F(uint16_t value)
{
	float p1=-38.741;
	float p2=103400;
	float q1=271;
	float temp=0;
	temp =((p1*value)+p2)/(value+q1);
	return temp;
}
//返回两个整数差
uint16_t num_sub( unsigned int a, unsigned int c )
{
	return ( a >= c ? ( a - c ) : ( c - a ) );
}

float user_ADC_Filter(user_ADC_FilterTypeDef* user_ADC,ADC_HandleTypeDef* hadc)
{
     

    uint16_t  new_value = 10;
	  static float temp =0;
	   static uint8_t count = 3;
    uint16_t  sum = 0;//求和值
//    new_value = Fit_GP2Y0A51SK0F(user_ADC1_GetValue(hadc));//刷新新值
	new_value=user_ADC1_GetValue(hadc);
	  if(count>0)
		{
			count--;
			value_buf[(user_ADC->head)++] =user_ADC-> middle_value;//在幅值以内则把新值送入数组
			user_ADC->last_value = user_ADC->middle_value;         //刷新上一次的值
			user_ADC->middle_value = new_value;         //刷新上一次的值

		}
//		else
//		{
//			value_buf[(user_ADC->head)++] = (uint16_t)((float)user_ADC->middle_value*0.8)+ (uint16_t)((float)new_value*0.2);
//			user_ADC->last_value = user_ADC->middle_value;         //刷新上一次的值
//			user_ADC->middle_value = new_value;         //刷新上一次的值
//		}
     else if( (num_sub( new_value, user_ADC->middle_value ) < A )&&(num_sub( user_ADC->last_value, user_ADC->middle_value ) < A )&&count==0)//判断幅值
    {

      value_buf[(user_ADC->head)++] = (uint16_t)((float)user_ADC->middle_value*0.6)+ (uint16_t)((float)new_value*0.4);
						user_ADC->last_value = user_ADC->middle_value;         //刷新上一次的值
			user_ADC->middle_value = new_value;         //刷新上一次的值

    }
    else
    {
        value_buf[(user_ADC->head)++] =(uint16_t)((float)user_ADC->middle_value*0.8)+ (uint16_t)((float)new_value*0.2);
						user_ADC->last_value = user_ADC->middle_value;         //刷新上一次的值
//			user_ADC->middle_value = ( new_value+(user_ADC->last_value))/2;         //刷新上一次的值
        user_ADC->middle_value = new_value;         //刷新上一次的值
    }

    switch(user_ADC->overflow_flag)
		{
			case 0:
			(user_ADC->sum)+=value_buf[(user_ADC->head)-1];
			temp = (user_ADC->sum)/(user_ADC->head);
			if( (user_ADC->head) == QUEUE_NUM )//当队列头到达最大队列数
			{
				(user_ADC->head) = 0;          //则返回到队列初始位置
				user_ADC->overflow_flag  = 1;
				(user_ADC->tail)=1;
			}			
			break;
			
			case 1:
			(user_ADC->sum)-=value_buf[(user_ADC->tail)++];	
			(user_ADC->sum)+=value_buf[(user_ADC->head)-1];	
			temp = (user_ADC->sum)/(QUEUE_NUM-1);
			if( (user_ADC->tail) == QUEUE_NUM )//当队列到达最大队列数
			{
					(user_ADC->tail) = 0;          //则返回到队列初始位置
			}		
			if( (user_ADC->head) == QUEUE_NUM )//当队列头到达最大队列数
			{
				(user_ADC->head) = 0;          //则返回到队列初始位置
			}			
			break;
		}
		temp=Fit_GP2Y0A51SK0F(temp);//刷新新值
    return temp;	
//		return new_value;
}