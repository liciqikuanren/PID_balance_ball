%% 导入电子表格中的数据
% 用于从以下电子表格导入数据的脚本:
%
%    工作簿: F:\STM32 Program\STM32F103C8T6 Program\PID_balance_ball\GP2Y0A51SK0F 数据表.xlsx
%    工作表: Sheet1
%
% 由 MATLAB 于 2023-06-26 17:23:40 自动生成

%% 设置导入选项并导入数据
opts = spreadsheetImportOptions("NumVariables", 2);

% 指定工作表和范围
opts.Sheet = "Sheet1";
opts.DataRange = "A3:B50";

% 指定列名称和类型
opts.VariableNames = ["X", "Y"];
opts.VariableTypes = ["double", "double"];

% 导入数据
tbl = readtable("F:\STM32 Program\STM32F103C8T6 Program\PID_balance_ball\GP2Y0A51SK0F 数据表.xlsx", opts, "UseExcel", false);

%% 转换为输出类型
X = tbl.X;
Y = tbl.Y;

%% 清除临时变量
clear opts tbl